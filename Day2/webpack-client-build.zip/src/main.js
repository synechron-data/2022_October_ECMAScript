// Imports an entire module, for side effects only, without importing anything from the file.
// This will run the module's global code, but doesn't import any values

// import './1_assignment/1_pure-impure-fn';
// import './1_assignment/2_fn-overloading';

// import './2_functions/1_closures';
// import './2_functions/2_fn-context';
// import './2_functions/3_hof';

// import './3_objects/1_object-creation';
// import './3_objects/2_object-type';
// import './3_objects/3_object-methods';
// import './3_objects/4_custom-types';
// import './3_objects/5_using-prototype';
// import './3_objects/6_es6-class';
// import './3_objects/7_compare';
// import './3_objects/8_es5-properties';
// import './3_objects/9_es6-properties';
// import './3_objects/10_es6-static';
// import './3_objects/11_es5-inheritance';
// import './3_objects/12_es6-inheritance';

// import './4_collections/1_arrays';
// import './4_collections/2_es6-map';
// import './4_collections/3_es6-set';

// import './5_iterators/1_well-known-symbols';
// import './5_iterators/2_custom-iterable';
// import './5_iterators/3_generators';

// import './6_modules/usage';

// import './7_promise/1_creating-promise';

import './8_ajax/dom-handler';