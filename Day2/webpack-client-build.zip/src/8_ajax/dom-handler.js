import postApiClient from "./post-api-client";

var ajaxDiv = document.getElementById("ajaxDiv");
var messageDiv = document.getElementById("messageDiv");

if (ajaxDiv.style.display === "none") {
    ajaxDiv.style.display = "block";
    messageDiv.style.display = "none";
}

var button = document.createElement("button");
button.className = "btn btn-primary";
button.innerHTML = "Get Data";

var btnArea = document.getElementById("btnArea");
btnArea.appendChild(button);

// button.addEventListener("click", function () {
//     alert("Button was clicked...");
// });

// 1. Using Callbacks
// button.addEventListener("click", function () {
//     postApiClient.getAllPostsUsingCallbacks((data) => {
//         generateTable(data);
//     }, (eMsg) => {
//         console.error(eMsg);
//     });
// });

// 2. Using Promise
// button.addEventListener("click", function () {
//     postApiClient.getAllPostsUsingPromise().then((data) => {
//         generateTable(data);
//     }).catch((eMsg) => {
//         console.error(eMsg);
//     });
// });

// 3. Using Async Await (ECMASCRIPT 2017)
// button.addEventListener("click", async function () {
//     try {
//         var data = await postApiClient.getAllPostsUsingPromise();
//         generateTable(data);
//     } catch (eMsg) {
//         console.error(eMsg);
//     }
// });

// 4. Using Async Function (ECMASCRIPT 2017)
// button.addEventListener("click", async function () {
//     try {
//         var data = await postApiClient.getAllPostsAsync();
//         generateTable(data);
//     } catch (eMsg) {
//         console.error(eMsg);
//     }
// });

// 5. Using Async Generators
button.addEventListener("click", async function () {
    const genObj = postApiClient.getAllPosts();
    
    try {
        var data = await genObj.next();
        generateTable(data.value);
    } catch (eMsg) {
        console.error(eMsg);
    }
});

function generateTable(data) {
    let table = document.getElementById("postTable");
    let row, cell;

    for (const item of data) {
        row = table.insertRow();
        cell = row.insertCell();
        cell.textContent = item.id;
        cell = row.insertCell();
        cell.textContent = item.title;
        cell = row.insertCell();
        cell.textContent = item.body;
    }
}