function getData() {
    var promise = new Promise((resolve, reject) => {
        // Async Code
        setTimeout(function () {
            resolve({ id: 1, name: "Manish" });
            // reject("Some Error...");
        }, 5000);
    });
    return promise;
}

var promise = getData();

console.log(typeof promise);
console.log(promise.constructor);
console.log(promise instanceof Promise);

console.log(typeof promise === 'object' && typeof promise.then === 'function');


// promise.then((data) => {
//     console.log("Success: ", data);
// }, (err) => {
//     console.error("Error: ", err);
// });

// promise.then((data) => {
//     console.log("Success: ", data);
// }).catch((err) => {
//     console.error("Error: ", err);
// });

// ECMASCRIPT 2018 - Promise finally
promise.then((data) => {
    console.log("Success: ", data);
}).catch((err) => {
    console.error("Error: ", err);
}).finally(() => {
    console.warn("Finally will always run");
});