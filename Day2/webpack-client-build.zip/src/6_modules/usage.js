// Case 1 - Default Import
// import square from './lib';
// console.log("Square: ", square(20));

// import sqr from './lib';
// console.log("Square: ", sqr(20));

// import * as l from './lib';
// console.log("Square: ", l.default(20));

// Case 2 - Named Import
// import { square } from './lib';
// console.log("Square: ", square(20));

// import { square as sqr } from './lib';
// console.log("Square: ", sqr(20));

// import * as l from './lib';
// console.log("Square: ", l.square(20));

// Case 3 - Multiple Imports
// import square, {check, test} from "./lib";
// console.log("Square: ", square(20));
// console.log("Check: ", check(20));
// console.log("Test: ", test(20));

// import sqr, {check as chk, test as tst} from "./lib";
// console.log("Square: ", sqr(20));
// console.log("Check: ", chk(20));
// console.log("Test: ", tst(20));

// import * as l from "./lib";
// console.log("Square: ", l.default(20));
// console.log("Check: ", l.check(20));
// console.log("Test: ", l.test(20));

import { Queue } from './lib';
let ordersQueue = new Queue();
ordersQueue.push("Order Id: 1");
ordersQueue.push("Order Id: 2");
ordersQueue.push("Order Id: 3");

for (const order of ordersQueue) {
    console.log(order);
}