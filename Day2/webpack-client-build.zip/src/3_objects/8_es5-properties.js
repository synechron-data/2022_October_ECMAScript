const Person = (function () {
    function Person(name, age = 0) {
        // Data Property
        this._name = name;
        this._age = age;
    }

    // Accessor Property
    Object.defineProperty(Person.prototype, "Name", {
        get: function () {
            return this._name;
        },
        set: function (value) {
            this._name = value;
        }
    });

    Object.defineProperty(Person.prototype, "Age", {
        get: function () {
            return this._age;
        },
        set: function (value) {
            this._age = value;
        }
    });

    return Person;
})();

var p1 = new Person("Manish");
console.log(p1.Name);
console.log(p1.Age);

p1.Name = "Abhijeet";
p1.Age = 10;

console.log(p1.Name);
console.log(p1.Age);