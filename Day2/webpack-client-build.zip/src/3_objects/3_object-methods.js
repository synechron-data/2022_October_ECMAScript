// ---------------------------------------------------- Object.assign (Shallow Copy)

// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// let obj1 = Object.assign({}, source);

// obj1.name = "Abhijeet";
// obj1.address.city = "Mumbai";

// console.log(source);
// console.log(obj1);

// ---------------------------------------------------- Object.create
// Creates a new object, using an existing object as the prototype of the newly created object.

// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// let obj1 = Object.assign({}, source);
// let obj2 = Object.create(source);

// console.log("Source: ", source);
// console.log("Assign: ", obj1);
// console.log("Create: ", obj2);

// ---------------------------------------------------
// Add a New Property       - Allowed
// Delete a Property        - Allowed
// Modify Property Value    - Allowed

// let source = { id: 1, name: "Manish" };

// // Add a New Property
// source.city = "Pune";
// console.log(source);

// // Delete a Property
// delete source.name;
// console.log(source);

// // Modify Property Value
// source.id = 1000;
// console.log(source);

// ---------------------------------------------------
// Add a New Property       - Not Allow
// Delete a Property        - Allowed
// Modify Property Value    - Allowed

// let source = { id: 1, name: "Manish" };

// Object.preventExtensions(source);

// // Delete a Property
// delete source.name;
// console.log(source);

// // Modify Property Value
// source.id = 1000;
// console.log(source);

// if (Object.isExtensible(source)) {
//     // Add a New Property
//     source.city = "Pune";
//     console.log(source);
// } else {
//     console.log("New properties can not be added to the object");
// }

// ---------------------------------------------------
// Add a New Property       - Not Allow
// Delete a Property        - Not Allow
// Modify Property Value    - Allowed

// let source = { id: 1, name: "Manish" };

// Object.seal(source);

// // Modify Property Value
// source.id = 1000;
// console.log(source);

// if (!Object.isSealed(source)) {
//     // Add a New Property
//     source.city = "Pune";
//     console.log(source);

//     // Delete a Property
//     delete source.name;
//     console.log(source);
// } else {
//     console.log("New properties can not be added and old properties can not be deleted on the object");
// }

// ---------------------------------------------------
// Add a New Property       - Not Allow
// Delete a Property        - Not Allow
// Modify Property Value    - Not Allow

let source = { id: 1, name: "Manish" };

Object.freeze(source);

if (!Object.isFrozen(source)) {
    // Add a New Property
    source.city = "Pune";
    console.log(source);

    // Delete a Property
    delete source.name;
    console.log(source);

    // Modify Property Value
    source.id = 1000;
    console.log(source);
} else {
    console.log("Object is freezed");
}