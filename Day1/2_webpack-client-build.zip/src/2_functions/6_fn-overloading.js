// function hello() {
//     console.log("Hello World!");
// }

// // Syntax Error: Identifier 'hello' has already been declared.
// function hello(name) {
//     console.log(`Hello ${name}`);
// }

// hello();
// hello("Manish");

// ------------------------------------

// function m1() {
//     console.log("Hello World!");
// }

// function m2(name) {
//     console.log(`Hello ${name}`);
// }

// function hello() {
//     if (arguments.length === 0)
//         m1();
//     else if (arguments.length === 1)
//         m2(arguments[0]);
//     else
//         throw Error("Invalid Parameters...");
// }

// hello();
// hello("Manish");

// m1();
// m2("Manish");

// // ------------------------------------

// function hello() {
//     function m1() {
//         console.log("Hello World!");
//     }

//     function m2(name) {
//         console.log(`Hello ${name}`);
//     }

//     if (arguments.length === 0)
//         m1();
//     else if (arguments.length === 1)
//         m2(arguments[0]);
//     else
//         throw Error("Invalid Parameters...");
// }

// hello();
// hello("Manish");

// m1();                   // Error
// m2("Manish");           // Error

// ------------------------------------

// const hello = (function () {
//     function m1() {
//         console.log("Hello World!");
//     }

//     function m2(name) {
//         console.log(`Hello ${name}`);
//     }

//     return function() {
//         if (arguments.length === 0)
//             m1();
//         else if (arguments.length === 1)
//             m2(arguments[0]);
//         else
//             throw Error("Invalid Parameters...");
//     }
// })();

// hello();
// hello("Manish");

// ---------------------------------------

// function hello() {
//     if (arguments.length === 0)
//         console.log("Hello World!");
//     else if (arguments.length === 1)
//         console.log(`Hello ${arguments[0]}`);
//     else
//         throw Error("Invalid Parameters...");
// }

// hello();
// hello("Manish");

// --------------------------------------- Assignment

// Create an Add Function which 2 or 3 arguments and returns the sum of the numbers
// Use both the approach to create the function

console.log(Add(2, 3));
console.log(Add(2, 3, 4));
try {
    console.log(Add(2));        // Show Error, if you are passing less than 2 or more than 3 arguments
} catch (e) {
    console.error(e.message);
}