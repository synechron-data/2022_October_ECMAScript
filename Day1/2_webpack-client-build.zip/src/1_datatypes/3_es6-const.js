'use strict'

// var a;
// console.log("a is: ", a);

// let b;
// console.log("b is: ", b);

// SyntaxError: Missing initializer in const declaration. 
// const c;
// console.log("c is: ", c);

// const c = "dev";
// console.log("c is: ", c);

// TypeError: Assignment to constant variable.
// c = "prod";
// console.log("c is: ", c);

// -------------------------------------
// You cannot create a variable with same name using let keyword, in same scope

// const a = 10;
// const a = "Manish";                // Error: Identifier 'a' has already been declared.
// console.log("a is: ", a);
// console.log("Type of a is: ", typeof a);

// ------------------------------------------
// Const supports block Scoping

// const env = "dev";
// console.log("Outside Block, env is:", env);

// if (true) {
//     const env = "prod";
//     console.log("Inside Block, env is:", env);
// }

// ----------------------------------------------------

const person = { id: 1, name: "Manish" };
console.log(person);

person.id = 1000;
person.name = "Abhijeet";
person.city = "Pune";

console.log(person);

delete person.id;
console.log(person);

// person = { id: 20 };                  // TypeError: Assignment to constant variable.s
// console.log(person);