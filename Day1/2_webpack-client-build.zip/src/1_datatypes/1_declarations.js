"use strict"
// "use strict is not required when we use import or export statement in JS file"
console.log("Hello from declarations.js file");

// In strict mode, we will get error
// Without strict mode, a will be created in Global Scope
// a = 10;
// console.log("a is: ", a);

// ----------------------------------------------
// var a = "Hello";            // Local to the file 
// console.log("a is: ", a);

// ---------------------------------------------- Hoisting
// Hoisting - Hoisting is JavaScript Runtime's default behavior of moving declarations to the top before execution

// a = 10;
// console.log("a is: ", a);
// var a;

// // Only declarations are hoisted
// console.log("b is: ", b);
// var b = 20;

// Runtime gets the below code
// var b;
// console.log("b is: ", b);
// b = 20;

// // ------------------------------------- Not Typesafe (Dynamically Typed)
// var a = 10;
// console.log("a is: ", a);
// console.log("Type of a is: ", typeof a);

// a = "Manish";
// console.log("a is: ", a);
// console.log("Type of a is: ", typeof a);

// -------------------------------------
// You can create a variable with same name using var keyword
// Runtime will pick the nearest variable declaration/initilization

// var a = 10;
// var a = "Manish";
// console.log("a is: ", a);
// console.log("Type of a is: ", typeof a);

// ------------------------------------------------
// Only Global and Function Scope is supported when using var keyword

// Global to this module(file)
// var a = 10;

// function test() {
//     console.log("Inside test(), a is:", a);
// }

// test();
// console.log("Outside test(), a is:", a);

// ------------------------------

// var a = 10;

// function test() {
//     var a = 100;            // Local Variable (Function Scoped)
//     console.log("Inside test(), a is:", a);
// }

// test();
// console.log("Outside test(), a is:", a);

// --------------------------------------
// Block Scoping is not supported with var keyword

// var a = 10;

// function test() {
//     if (true) {
//         var a = 100;            // Local Variable (Function Scoped)
//         console.log("Inside block(), a is:", a);
//     }
//     console.log("Inside test(), a is:", a);
// }

// test();
// console.log("Outside test(), a is:", a);

// -------------------

var i = "Hello";
console.log("Before, i:", i);

// for (var i = 0; i < 5; i++) {
//     console.log("Inside Loop, i:", i);
// }

// for (var _i = 0; _i < 5; _i++) {
//     console.log("Inside Loop, _i:", _i);
// }

// function iterate() {
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside Loop, i:", i);
//     }
// }

// iterate();

// IIFE (Immediatly Invoked Function Expression)
(function () {
    for (var i = 0; i < 5; i++) {
        console.log("Inside Loop, i:", i);
    }
})();

console.log("After, i:", i);